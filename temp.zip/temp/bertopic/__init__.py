from bertopic._bertopic import BERTopic

__version__ = "0.9.1"

__all__ = [
    "BERTopic",
]
