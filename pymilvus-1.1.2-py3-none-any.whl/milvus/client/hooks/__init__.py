from .abstract import BaseSearchHook
