Browser tests
=============

These are headless browser tests which will only work in Python 3.

They should verify that all the example notebooks render without error.
