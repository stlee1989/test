from .config_example import sample_config
