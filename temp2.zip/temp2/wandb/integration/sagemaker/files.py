SM_PARAM_CONFIG = "/opt/ml/input/config/hyperparameters.json"
SM_RESOURCE_CONFIG = "/opt/ml/input/config/resourceconfig.json"
SM_SECRETS = "secrets.env"
