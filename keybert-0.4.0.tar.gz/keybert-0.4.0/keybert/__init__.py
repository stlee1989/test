from keybert._model import KeyBERT

__version__ = "0.4.0"
