from . import gzip  # noqa: F401
