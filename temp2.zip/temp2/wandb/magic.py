from wandb.integration import magic


magic.magic_install()
