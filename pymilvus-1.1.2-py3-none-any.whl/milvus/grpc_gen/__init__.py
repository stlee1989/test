# -*- coding: utf-8 -*-

__all__ = ['status_pb2', 'status_pb2_grpc', 'milvus_pb2', 'milvus_pb2_grpc']
