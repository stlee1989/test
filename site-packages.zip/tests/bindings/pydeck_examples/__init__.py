from .minimal import create_minimal_test_object  # noqa
from .hexagon_layer_function import create_heatmap_test_object  # noqa
from .geojson_layer import create_geojson_layer_test_object  # noqa
from .geojson_layer_with_gmaps import create_geojson_layer_with_gmaps_test_object  # noqa
from .multilayers import create_multi_layer_test_object  # noqa
from .scatterplot import create_scatterplot_test_object  # noqa
from .stacked import create_stacked_test_object  # noqa
